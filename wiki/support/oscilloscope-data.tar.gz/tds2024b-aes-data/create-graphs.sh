#!/bin/sh

for d in */ ; do
  name="${d/\//}"
  awk -F, '{
    split(FILENAME, f, "/");
    print substr(f[2], 6, 2) $4 '\t' $5
  }' $name/*/*.CSV | sed 's/   //g' > "$name.csv"

  gnuplot > "$name.png" <<EOF
    reset
    set terminal png size 1600,900

    set xlabel "Time (s)"
    set ylabel "Voltage (V)"

    set title "Power profile from AES driver for CC2538 ($name)"
    unset key
    set grid

    plot "$name.csv"
EOF
  done
